# WidgetCreate

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** |  |  [optional]
**x** | **Integer** |  | 
**y** | **Integer** |  | 
**z** | **Integer** |  |  [optional]
