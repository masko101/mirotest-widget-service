# Widget

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** |  | 
**x** | **Integer** |  | 
**y** | **Integer** |  | 
**z** | **Integer** |  |  [optional]
